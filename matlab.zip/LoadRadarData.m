clear all;
clc;
close all;

addpath("./npy-matlab");
addpath("./jsonlab-2.0");
addpath("D:\LASSO\dataset_60GHz\data0108\2024_1_8_data220240108-160332\RadarIfxAvian_00");

%% Load Data
RadarData = readNPY("radar.npy");  
[NumFrame,NumRx,NumChirp,NumSample] = size(RadarData); %Frame， RX， Chirp， Samples

%% Config Init
c = physconst('lightspeed');
Config = loadjson("test1config.json");
Fc = (Config.device_config.fmcw_single_shape.start_frequency_Hz + Config.device_config.fmcw_single_shape.end_frequency_Hz)/2;
lamda = c/Fc;  %Wave Length
Fs = Config.device_config.fmcw_single_shape.sample_rate_Hz; %Sample Rate
ChirpInterval = Config.device_config.fmcw_single_shape.chirp_repetition_time_s;
FrameInterval = Config.device_config.fmcw_single_shape.frame_repetition_time_s;
ChirpDuration = 1/Fs*NumSample + ChirpInterval;
FrameDuration = ChirpDuration*NumChirp + FrameInterval;

%% Signal Processing
PlotRawData = squeeze(RadarData(1,:,1,:));
figure
for idxRx = 1:NumRx
    plot(PlotRawData(idxRx,:)); hold on;
end
legend('Rx1','Rx2','Rx3')
hold off;

%% Range-Doppler
idxFrame = 1;
idxRx = 1;

TempChirpData = squeeze(RadarData(idxFrame,idxRx,:,:));
RDfft = fft2(TempChirpData,NumChirp,NumSample);
array_range = 1:256;
array_Doppler = 1:16;
figure
nexttile
imagesc(array_range,array_Doppler,db(RDfft));
colorbar;
xlabel('frequency offset');
ylabel('Time');
title('Raw Doppler');